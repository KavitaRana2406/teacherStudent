package com.restApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherStudentApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
