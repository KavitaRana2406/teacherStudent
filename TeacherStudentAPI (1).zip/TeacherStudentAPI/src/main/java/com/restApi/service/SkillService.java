package com.restApi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restApi.entity.Document;
import com.restApi.entity.Skill;
import com.restApi.repository.DocumentRepositoty;
import com.restApi.repository.SkillRepository;

@Service
public class SkillService {
	
	@Autowired
	private SkillRepository skillRepo;
	
	@Autowired
	private DocumentRepositoty docRepo;
	
	
	
	public Skill addSkill(Skill skill)
	{
		
		Skill new_entity=skillRepo.save(skill);
		return new_entity;
		
	}
	
	public List <Skill> findAllSkills()
	{
		
		List<Skill> skills=skillRepo.findAll();
		return skills;
	}
	
	
	
 
}
