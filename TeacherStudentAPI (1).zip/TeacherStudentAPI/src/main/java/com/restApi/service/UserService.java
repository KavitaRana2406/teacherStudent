package com.restApi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restApi.entity.Student;
import com.restApi.entity.Teacher;
import com.restApi.entity.User;
import com.restApi.repository.StudentRepository;
import com.restApi.repository.TeacherRepository;

@Service
public class UserService {
	@Autowired
	private StudentRepository studentRepo;

	@Autowired
	private TeacherRepository teacherRepo;

	/*public User userRegister(User user, String category) {
		if (category.equalsIgnoreCase("Student")) {
			Student entity = Student.builder().age(user.getAge()).category(user.getCategory())
					.contactNumber(user.getContactNumber()).firstName(user.getFirstName()).gender(user.getGender())
					.Id(user.getId()).lastName(user.getLastName()).password(user.getPassword())
					.userName(user.getUserName()).build();
			return studentRepo.save(entity);
		} else {
			Teacher entity = Teacher.builder().age(user.getAge()).category(user.getCategory())
					.contactNumber(user.getContactNumber()).firstName(user.getFirstName()).gender(user.getGender())
					.Id(user.getId()).lastName(user.getLastName()).password(user.getPassword())
					.userName(user.getUserName()).build();
			return teacherRepo.save(entity);
		}
	}*/
	public User userRegister(User user) {
		if (user.getCategory().toString().equalsIgnoreCase("Student")) {
			Student entity = Student.builder().age(user.getAge()).category(user.getCategory())
					.contactNumber(user.getContactNumber()).firstName(user.getFirstName()).gender(user.getGender())
					.Id(user.getId()).lastName(user.getLastName()).password(user.getPassword())
					.userName(user.getUserName()).build();
			return studentRepo.save(entity);
		} else {
			Teacher entity = Teacher.builder().age(user.getAge()).category(user.getCategory())
					.contactNumber(user.getContactNumber()).firstName(user.getFirstName()).gender(user.getGender())
					.Id(user.getId()).lastName(user.getLastName()).password(user.getPassword())
					.userName(user.getUserName()).build();
			return teacherRepo.save(entity);
		}
	}
}
