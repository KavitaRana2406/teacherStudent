package com.restApi.constants;

public enum Gender {
	Male ,
	Female;
}
