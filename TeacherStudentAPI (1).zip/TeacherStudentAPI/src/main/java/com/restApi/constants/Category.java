package com.restApi.constants;

public enum Category {
	Student,Teacher;
}
