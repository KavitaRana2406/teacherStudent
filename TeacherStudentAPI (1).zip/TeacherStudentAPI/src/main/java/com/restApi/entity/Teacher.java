package com.restApi.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
public class Teacher extends User {

	@Column(name="teacher_spcl")
	private String specialization;
	
	@OneToMany(targetEntity=Schedule.class,cascade=CascadeType.ALL,mappedBy="")
	@JoinColumn(
			name="teacher_schedule")
	private List<Schedule> ListOfSchedule;
	
	@Column(name="no_of_students")
	private int noOfStudents;
	
	@Column(name="planned_leaves")
	private int plannedLeaves;
}
