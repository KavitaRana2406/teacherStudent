package com.restApi.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
public class Student extends User{
	@Column(name="student_spcl")
	private String specialization;
	
	@ManyToOne(
			targetEntity=Batch.class,
			cascade=CascadeType.ALL
			)
	@JoinColumn(
			name="batchId"
			)
	private Batch batch;
	
	@OneToMany(targetEntity=Document.class,cascade=CascadeType.ALL)
	@JoinColumn(
			name="documents"
			)
	private List<Document> documents;
}
