package com.restApi.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.restApi.constants.Gender;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name="Admin")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long Id;
	
	@NotNull(message="Admin Id should be unique and it is mendatory.")
	@Column(name="Admin_Id", nullable = false, unique = true, length = 45)
	private String adminId;
	
	@NotNull(message="First Name is mendatory.")
	@Column(name="first_name")
	private String firstName;
	
	@NotNull(message="Last Name is mendatory.")
	@Column(name="last_name")
	private String lastName;
	
	@NotNull(message="Please enter a valid age.")
	@Column(name="age")
	private int age;
	
	@NotNull(message="Please choose a valid gender.")
	@Column(name="gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@NotNull(message="Please enter valid mobile number.")
	@Pattern(regexp="(^$|[0-9]{10})")
	@Column(name="contact_number")
	private Long contactNumber;
	
	@Column(name="password")
	private String password;
	
	@Column(name="picture")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] picture;
}