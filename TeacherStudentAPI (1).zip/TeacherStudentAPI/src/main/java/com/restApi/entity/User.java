package com.restApi.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import com.restApi.constants.Category;
import com.restApi.constants.Gender;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@MappedSuperclass
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long Id;
	
	@NotNull(message="User Id should be unique and it is mendatory.")
	@Column(name="User_Name", nullable = false, unique = true, length = 45)
	private String userName;
	
	@NotNull(message="First Name is mendatory.")
	@Column(name="first_name")
	private String firstName;
	
	@NotNull(message="Last Name is mendatory.")
	@Column(name="last_name")
	private String lastName;
	
	@NotNull(message="Please enter a valid age.")
	@Column(name="age")
	private int age;
	
	@NotNull(message="Please choose a valid gender.")
	@Column(name="gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@NotNull(message="Please enter valid mobile number.")
	//@Pattern(regexp="(0/91)?[7-9][0-9]{9}")
	@Column(name="contact_number")
	private Long contactNumber;
	
	@NotNull(message="Select a valid category")
	@Column(name="category")
	@Enumerated(EnumType.STRING)
	private Category category;
	
	@Column(name="password")
	private String password;
	
	@Column(name="picture")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] picture;

}