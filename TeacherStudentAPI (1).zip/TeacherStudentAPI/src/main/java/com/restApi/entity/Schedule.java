package com.restApi.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="schedules")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Schedule {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="sch_Id")
	private int scheduleId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="sch_date")
	private Date date;
	
	@Temporal(TemporalType.TIME)
	@Column(name="sch_time")
	private Date time;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "batchId")
	private Batch batch;
	
	@Column(name="sch_subject")
	private String subject;
	
	@OneToMany(targetEntity=Document.class,cascade=CascadeType.ALL)
	@JoinColumn(
			name="sch_notes"
			)
	private List<Document> notes;
	
	@ManyToOne
    @JoinColumn(name="teacher_id", nullable=false)
	private Teacher teacher;
}
